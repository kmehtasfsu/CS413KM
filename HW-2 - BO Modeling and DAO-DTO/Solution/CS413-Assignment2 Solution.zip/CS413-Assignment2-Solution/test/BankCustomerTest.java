/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import cs413.assignment2.solution.*;
import cs413.assignment2.controller.*;
import org.junit.*;

/**
 *
 * @author karunmehta
 */
public class BankCustomerTest {


    private static BankCustomer bankCustomer;

    @BeforeClass
    public static void setUp() {
        bankCustomer = new BankCustomer("John", "Doe");
        
    }
      

    @Test
    public void testCustomerCreation() {
        
        Assert.assertEquals("John Doe", bankCustomer.getName());
        Assert.assertEquals("John", bankCustomer.getFirstName());
        Assert.assertEquals("Doe", bankCustomer.getLastName());
    }

    @Test
    public void testCustomerSave() {
        
        BankCustomer cust = new BankCustomer("Jason", "Borne");
        cust.setEmail("jborne@sfsu.edu");
        cust.setPhone("415-555-7000");
        int createResult = CustomerDTO.performCreate(cust);        
        
        Assert.assertEquals(1, createResult);
    }    

}
