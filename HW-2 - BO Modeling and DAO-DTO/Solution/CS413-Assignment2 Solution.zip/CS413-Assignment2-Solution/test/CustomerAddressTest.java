/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import cs413.assignment2.solution.*;
import org.junit.*;

/**
 *
 * @author karunmehta
 */
public class CustomerAddressTest {
    
    private static BankCustomer bc;
    
    public CustomerAddressTest() {
    }
    
    @BeforeClass
    public static void setUp() {
        bc = new BankCustomer("John", "Doe");
        
        CustomerAddress a1 = new CustomerAddress(1234, "Test Street 1", "Test City 1", "Test State 1", 94536);
        bc.setAddress(a1);
         
    }

    @Test
    public void testAddress() {
        
        CustomerAddress theAddr = bc.getAddress();
        Assert.assertEquals("Street Num test failed",1234, theAddr.getStreetNum());
        Assert.assertEquals("Street Name test failed","Test Street 1", theAddr.getStreetName());
        Assert.assertEquals("City name test failed","Test City 1", theAddr.getCity());
        Assert.assertEquals("State name test failed","Test State 1", theAddr.getState());
        Assert.assertEquals("Zip num test failed",94536, theAddr.getZip());
    
    }
}
