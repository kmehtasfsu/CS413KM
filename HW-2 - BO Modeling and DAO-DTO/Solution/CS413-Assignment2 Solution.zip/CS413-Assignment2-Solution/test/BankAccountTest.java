
import cs413.assignment2.solution.*;
import java.util.*;
import org.junit.*;
import org.hamcrest.*;

/**
 *
 * @author karunmehta
 */
public class BankAccountTest {
    
    private static BankCustomer bc;
    private static BankAccount ba1;
    private static BankAccount ba2;

    
    public BankAccountTest() {
    }
        
    @BeforeClass
    public static void setUp() {

        ba1 = new CheckingAccount(1000);
        ba2 = new SavingsAccount(2000);
        List al = Arrays.asList(ba1, ba2);
        
        bc = new BankCustomer("John", "Doe");
        bc.setAccounts(al);
              
    }
    
    @Test
    public void testAccountCreation() {
        
        Assert.assertEquals(1000,ba1.getBalance());
        Assert.assertEquals(2000, ba2.getBalance());
        Assert.assertEquals(1, ba1.compareTo(ba2));
    }    

    @Test
    public void testAccountSave() {
        
    }       
    
    @Test
    public void testCustomerAccountRelation() {

        List accts = bc.getAccounts();
        Assert.assertEquals(2, accts.size());
        Assert.assertEquals(ba1, accts.get(0));
        Assert.assertEquals(ba2, accts.get(1));
    }    
    
}
