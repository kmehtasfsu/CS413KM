/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.lang.*;
import java.io.*;
import java.util.List;
import java.util.Iterator;
import java.net.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.core.type.TypeReference;
import cs413.assignment2.solution.*;

import javax.json.*;


 /*
 * @author karunmehta
 */
public class TestJason {

    static ObjectMapper objectMapper = null;

    static String jsonBankCustomerString = "{ \"firstName\" : \"James\",\"lastName\" : \"Madison\", \"email\" : \"jmadison@sfsu.edu\", \"phone\" : \"777-1212\", \"customerNumber\" : \"100\" }";
    static String jsonBankCustomersString = "[{ \"firstName\" : \"James\",\"lastName\" : \"Madison\", \"email\" : \"jmadison@sfsu.edu\", \"phone\" : \"777-1212\", \"customerNumber\" : \"100\" }, { \"firstName\" : \"Robert\",\"lastName\" : \"Deniro\", \"email\" : \"rdeniro@sfsu.edu\", \"phone\" : \"415-555-7171\", \"customerNumber\" : \"200\" }]";
    
    public static void main(String[] args) {

        // Parse JSON string to JsonNode
        objectMapper = new ObjectMapper();
        
        System.out.println("\nCreating Employee object"); 
        
        //create BankCustomer object
        BankCustomer cust = new BankCustomer("Paula Abdul", "pabdul@sfsu.edu");
        String custString = new String(); 
        
        //create string version of the employee object
        try {
            custString = objectMapper.writeValueAsString(cust);
        } catch(JsonProcessingException jpe) {
            System.out.println("error creating JSON String for BankCustomer Object: " + jpe.getMessage());
        }
        
        System.out.println("\nJSON String version of Employee object\n" + custString);
        
        
        //Read in employee strings as json tree
        try {
            JsonNode jsonCustomerNode = objectMapper.readTree(jsonBankCustomerString);
            JsonNode jsonNode2 = objectMapper.readTree(jsonBankCustomersString);

            // Accessing JSON properties
            String fname = jsonCustomerNode.get("firstName").asText();
            String lname = jsonCustomerNode.get("lastName").asText();
            String email = jsonCustomerNode.get("email").asText();
            String phone = jsonCustomerNode.get("phone").asText();
            String id = jsonCustomerNode.get("customerNumber").asText();
            
            System.out.println("Customer Details: \n" + "Name: " + fname + " " + lname + " Email: " + email + " Phone: " + phone + " Cust Num: " + id);
            
            System.out.println("\nSingle Employee Detail JSON String:");
            String treeString = jsonCustomerNode.toPrettyString();
            System.out.println(treeString);
            
            System.out.println("\nMultiple Employee Detail JSON String:");
            treeString = jsonNode2.toPrettyString();
            System.out.println(treeString);
            
            System.out.println("\nNow printing each employee detail: ");
            
            Iterator it = jsonNode2.elements();
            while(it.hasNext()) {
                
                JsonNode jNode = (JsonNode)it.next();

                // Printing JSON properties for the current node
                System.out.println("\nName: " + jNode.get("firstName").asText());
                System.out.println("email1: " + jNode.get("email").asText());
                System.out.println("phone1: " + jNode.get("phone").asText());
                System.out.println("Id1: " + jNode.get("customerNumber").asText());
            
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Working with BankCustomer Objects
        readJsonBankCustomer();
        readJsonBankCustomers();
    }
   
    //Read in single customer
    public static void readJsonBankCustomer() {

        BankCustomer custObj = null;
        
        try {
            custObj = objectMapper.readValue(jsonBankCustomerString, BankCustomer.class);
        } catch(JsonProcessingException jpe) {
            System.out.println(jpe.getMessage());
        }
        
        //Getting data from Employee object created from JSON String
        System.out.println("\nReading data from JSON String of single employee:"); 
        if (custObj != null) {
            System.out.println("Name: " + custObj.getFirstName() + " " + custObj.getLastName());
            System.out.println("Email: " + custObj.getEmail());
            System.out.println("Phone: " + custObj.getPhone());
            System.out.println("ID: " + custObj.getCustomerNumber());
        }
    }

    //Read in multiple customers
    public static void readJsonBankCustomers() {

        List<BankCustomer> custList = null;
        
        try {
            custList = objectMapper.readValue(jsonBankCustomersString, new TypeReference<List<BankCustomer>>(){});
        } catch(JsonProcessingException jpe) {
            System.out.println(jpe.getMessage());
        }

        Iterator it = custList.iterator();
        
        System.out.println("\nReading data from multiple employees in JSON array:"); 
        
        while(it.hasNext()) {
            
            BankCustomer cust = (BankCustomer)it.next();
            System.out.println("Name: " + cust.getFirstName() + " " + cust.getLastName());
            System.out.println("Email: " + cust.getEmail());
            System.out.println("Phone: " + cust.getPhone());
            System.out.println("ID: " + cust.getCustomerNumber() + "\n");
        }

    }     
    
}
