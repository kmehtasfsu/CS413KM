import cs413.assignment2.solution.*;
import java.util.*;
import java.time.LocalDate;
import org.junit.*;

/**
 *
 * @author karunmehta
 */
public class AccountPQTest {
    
    private static BankAccount ba1, ba2, ba3;
    private static List al;
    private static MyPriorityQueue mypq;
    
    public AccountPQTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        
        ba1 = new CheckingAccount(1000);
        ba2 = new SavingsAccount(2000);
        
        ba2.setCreateDate(ba2.getCreateDate().minusDays(5)); 
        
        //al = Arrays.asList(ba1, ba2);
        
        mypq = new MyPriorityQueue<BankAccount>();
        try {
            mypq.enqueue(ba1);
            mypq.enqueue(ba2);
        } catch(Exception e) {
            System.out.println("Error during JUnit Testing: " + e.getMessage());
        }
       
    }
    
    @Test
    public void buildAndAddToPQ() {
        
        BankAccount queueHead = null;
        
        System.out.println("PQ initial state: " + mypq.toString());
        
        //create new account with older date to check if PQ prioritizes it correctly
        ba3 = new SavingsAccount(3000);
        
        LocalDate dt = ba3.getCreateDate().minusDays(10);
        ba3.setCreateDate(dt);
        mypq.enqueue(ba3);
        
        System.out.println("PQ after adding new account with date 10 days in past: \n " + mypq.toString());
        
        queueHead = (BankAccount)mypq.dequeue();
        Assert.assertEquals("Test Failed", queueHead, ba3);        
        
        queueHead = (BankAccount)mypq.dequeue();
        Assert.assertEquals("Test Failed", queueHead, ba2);       

        queueHead = (BankAccount)mypq.dequeue();
        Assert.assertEquals("Test Failed", queueHead, ba1);
        
        boolean isItEmpty = mypq.isEmpty();
        Assert.assertEquals("Test Failed", true, isItEmpty);
    }
    
}
