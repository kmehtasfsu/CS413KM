/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cs413.assignment2.controller;

import cs413.assignment2.solution.*;
import java.sql.SQLException;
import java.util.HashMap;

/**
 *
 * @author karunmehta
 */
public class CustomerDTO {
    
    private int id;
    private String username;
    private String email;
    private String phone;
   
    static CustomerDAO cd = new CustomerDAO();

    public CustomerDTO() {
        

    }

    public CustomerDTO(int empID, String username, String email) {

        this.username = username;
        this.email = email;
        id = empID;
    }

    public CustomerDTO(String username, String email, String ph) {
        
        this.username = username;
        this.email = email;
        this.phone = ph;
    }    
    
    // Getter and Setter methods
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }    
    
    public String getPhone() {
        return phone;
    }

    public void setPhone(String ph) {
        this.phone = ph;
    }
    
    public int getID() {
        
        return id;
    }

    public void setID(int anID) {
        this.id = anID;
    }  
    
    public static BankCustomer customerByID(int anId) {
        
        BankCustomer anCustomer = null;
        
        try {
            anCustomer = cd.get(anId);
        } catch(SQLException se) {
            System.out.println(se.getMessage());
        }
        if(anCustomer != null) System.out.println(anCustomer.toString()); 
            
        System.out.println("\nFetched Customer with ID: " + anId + " Customer Details:\n" + anCustomer.toString());        
        return anCustomer;
        
}
    
    public static int performUpdate(BankCustomer aCustomer) {

        int updateResult = -1;
        
        try {
            updateResult = cd.update(aCustomer);
        } catch(SQLException se) {
            System.out.println(se.getMessage());
        }
        
        if(updateResult != -1) System.out.println("\nUpdate Successful");
         System.out.println("Customer Details:\n" + aCustomer.toString());
        return updateResult;        
    }

    public static int performCreate(BankCustomer aCustomer) {

        int updateResult = -1;
        
        
        
        try {
            updateResult = cd.create(aCustomer);
        } catch(SQLException se) {
            System.out.println(se.getMessage());
        }
        
         if(updateResult != -1) System.out.println("\nCustomer Create Successful");
         System.out.println("Customer Details:\n" + aCustomer.toString());
        return updateResult;        
    }
}