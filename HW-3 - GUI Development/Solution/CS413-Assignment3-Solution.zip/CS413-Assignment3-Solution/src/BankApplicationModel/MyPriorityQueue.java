/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BankApplicationModel;

/**
 *
 * @author karunmehta
 */
public class MyPriorityQueue<T extends Comparable<T>> implements QueueInterface<T>{
    
    private Node firstNode; // Reference to first node of chain and the front
                           // of the priority queue, which has the highest priority
    private int  length;    // Number of entries in chain


    public MyPriorityQueue() {
        
      firstNode = null;
      length = 0;
   
    } // end default constructor

    @Override
   public void enqueue(T newEntry) {
    
       Node newNode = new Node(newEntry);
       Node nodeBefore = getNodeBefore(newEntry);

       if (isEmpty() || (nodeBefore == null)) { // Add at beginning

          newNode.setNextNode(firstNode);
          firstNode = newNode;
       } else if (this.getSize() == 1) {           
           newNode.setNextNode(nodeBefore);
           firstNode = newNode;
       } else {    
           // Add after nodeBefore 
           Node nodeAfter = nodeBefore.getNextNode();
           newNode.setNextNode(nodeAfter);
           nodeBefore.setNextNode(newNode);
        } // end if

        length++;
        
   } // end add

   @Override
    public T dequeue() {
       
      T element = firstNode.getData();
      
      firstNode = firstNode.getNextNode();
      
      length--;
      
      return element;  // 1-based, so this is the front
   
    } // end remove

    @Override
    public T getFront() throws EmptyQueueException {
        
       if(isEmpty())
           throw new EmptyQueueException("Trying to get first entry of an empty queue");
       else
        return firstNode.getData();

    } // end getFront

    @Override
    public boolean isEmpty() {
       
        boolean result;
            
        if (length == 0) {
            assert firstNode == null;
            result = true;
        } else  {
         assert firstNode != null;
         
         result = false;
        } // end if
         
        return result;

    } // end isEmpty

    public int getSize() {
        
       return length;
   
    }

    @Override
    public void clear() {
       
        firstNode = null;
        length = 0;
    } // end clear


    // Returns either a reference to the node that is before the node 
    // that contains or should contain anEntry, or null if
    // no prior node exists (that is, if anEntry belongs at
    // the beginning of the chain) 
    private Node getNodeBefore(T anEntry) {
        
        Node currentNode = firstNode;
        Node nodeBefore = null;
     
        while ( (currentNode != null) && (anEntry.compareTo(currentNode.getData()) >= 0) ){
           
            nodeBefore = currentNode;
            currentNode = currentNode.getNextNode();
        } // end while
     
     return nodeBefore;
   
    } // end getNodeBefore


    private Node getNodeAt(int givenPosition) {
    
        assert !isEmpty() && (1 <= givenPosition) && (givenPosition <= length);
        Node currentNode = firstNode;

        // Traverse the chain to locate the desired node
        for (int counter = 1; counter < givenPosition; counter++)
         currentNode = currentNode.getNextNode();

        assert currentNode != null;
        return currentNode;
   
    } // end getNodeAt
  
    @Override
    public String toString() {

        String str;
        
        Node currentNode = firstNode;
        
        T element = (T)currentNode.getData();
        str = "\n { " + element.toString() + " ";
        
        while( (currentNode.getNextNode() != null) ) {
            currentNode = currentNode.getNextNode();
            element = (T)currentNode.getData();
            str = str + " " + element;  
        }
        
        str = str + " }";
        return str;
        
    }
   
    private class Node {
        
        private T    data; // Entry in priority queue
        private Node next; // Link to next node

      
        private Node(T dataPortion) {
            data = dataPortion;
            next = null;	
        } // end constructor
      
      
        private Node(T dataPortion, Node nextNode) {
            
            data = dataPortion;
            next = nextNode;	
      
        } // end constructor
      
    
        private T getData() {

            return data;
      
        } // end getData
      
        private void setData(T newData) {
          
            data = newData;
        } // end setData
      
      
        private Node getNextNode() {
          
            return next;
        
        } // end getNextNode
      
      
        private void setNextNode(Node nextNode) {
            
            next = nextNode ;
            
        } // end setNextNode
        
    } // end Node class
    
} // end LinkedPriorityQueue

