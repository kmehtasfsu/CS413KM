/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dtoanddaodemo;

import java.sql.Connection;
import java.sql.SQLException;
import org.modelmapper.ModelMapper;

/**
 *
 * @author karunmehta
 */
public class DTOAndDAODemo {

    /**
     * @param args the command line arguments
     */
    
    static Connection conn;
    private final static EmployeeDAOConcrete ed = new EmployeeDAOConcrete();
    static String sampleUsername = "George Washinton";
    static String sampleEmail = "gwashington@sfsu.edu";
    static String samplePhone = "212-555-1212";
             
    
    public static void main(String[] args) {

        Employee emp;
        int updateID = 2;
        int fetchID = 1;

        try {
            conn = EmployeeDataConnection.getDBConnection();            
        } catch (SQLException se) {
            System.out.println(se.getMessage());
        }

        //Fetch an employee with the given ID
        emp = performFetch(fetchID);
        
        //Create an emplyee to update
        emp = new Employee(updateID, sampleUsername, sampleEmail, samplePhone);
        
        performUpdate(emp);
        
        //disconnect db conneciton
        try {
            EmployeeDAOConcrete.disconnect();
        } catch(SQLException se) {
            System.out.println("Exception trying to close connection. Message: \n" + se.getMessage());
        }
        
        testModelMapper();
        
    }
    
    private static Employee performFetch(int empID) {
        
        return EmployeeDTO.employeeByID(empID);
        
    }
    
    private static int performUpdate(Employee anEmployee) {
        
        return EmployeeDTO.performUpdate(anEmployee);
        
    }    
    
    private static void testModelMapper() {
        
        //create model mapper
        ModelMapper modelMapper = new ModelMapper();
        
        //Create Data Transfer Object based on Business Object
        EmployeeDTO employeeDTO = new EmployeeDTO(sampleUsername, sampleEmail, samplePhone);
        
        //Create Business Object from the DTO Objetc
        Employee anEmployee = modelMapper.map(employeeDTO, Employee.class); 
        
        System.out.println("\nSuccessfully mapped and unmapped employee with ID: " + anEmployee.getID() + " with employee Details:\n" + anEmployee.toString());
    }

}

